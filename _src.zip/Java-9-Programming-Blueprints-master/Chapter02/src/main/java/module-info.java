module procman.app {
    requires javafx.controls;
    requires javafx.fxml;
}