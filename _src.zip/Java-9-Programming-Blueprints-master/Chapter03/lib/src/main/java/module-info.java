module dupefind.lib {
    exports com.steeplesoft.dupefinder.lib;
    exports com.steeplesoft.dupefinder.lib.model;

    requires java.logging;
    requires javax.persistence;
}