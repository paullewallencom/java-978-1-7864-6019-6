module dupefind.cli {
    requires dupefind.lib;
    requires tomitribe.crest;
    requires tomitribe.crest.api;
}